<?php  session_start(); //this must be the very first line on the php page, to register this page to use session variables
	session_destroy();

	Header ("Location:lab4.php");
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="EN" dir="ltr" xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<title>Logout</title>
	<style type = "text/css">
  		h1, h2 {
    		text-align: center;
  		}
	</style>

	</head>

	<body>

			<h1>Logout</h1>
			Thank you for visiting our web site!

			
		



	</body>
</html>
